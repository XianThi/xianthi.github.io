//
//  FRPValueCell.h
//  FRPreferences
//
//  Created by Fouad Raheb on 7/22/15.
//  Copyright (c) 2015 F0u4d. All rights reserved.
//

#import "FRPCell.h"

@interface FRPValueCell : FRPCell

+ (instancetype)cellWithTitle:(NSString *)title detail:(NSString *)detail;

@end
